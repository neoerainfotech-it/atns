<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;
use CodeIgniter\Validation\StrictRules\CreditCardRules;
use CodeIgniter\Validation\StrictRules\FileRules;
use CodeIgniter\Validation\StrictRules\FormatRules;
use CodeIgniter\Validation\StrictRules\Rules;

class Validation extends BaseConfig
{
    // --------------------------------------------------------------------
    // Setup
    // --------------------------------------------------------------------

    /**
     * Stores the classes that contain the
     * rules that are available.
     *
     * @var string[]
     */
    public array $ruleSets = [
        Rules::class,
        FormatRules::class,
        FileRules::class,
        CreditCardRules::class,
        // FIXED: Removed the non-existent MyRules class entry that was breaking the upgrade boot loop
    ];

    /**
     * Specifies the views that are used to display the
     * errors.
     *
     * @var array<string, string>
     */
    public array $templates = [
        'list'      => 'CodeIgniter\Validation\Views\list',
        'single'    => 'CodeIgniter\Validation\Views\single',
        'my_list'   => 'CodeIgniter\Validation\Views\_list_error',
        'my_single' => 'CodeIgniter\Validation\Views\_single_error',
    ];

    // --------------------------------------------------------------------
    // Rules
    // --------------------------------------------------------------------
}